// parse.h
#include <vector>
#include <string>

std::vector<std::string> parse_message(const std::string& msg, char delimiter = '$');
